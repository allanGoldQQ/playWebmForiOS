//
//  ViewController.swift
//  KDAnimatedImageDemo
//
//  Created by Dolphinsu on 2021/10/17.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

